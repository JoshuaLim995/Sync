package klogi.com.notificationbyschedule;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/***
 * Created by klogi
 *
 * Activity which starts by clicking notification
 */
public class NotificationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);
    }

}
